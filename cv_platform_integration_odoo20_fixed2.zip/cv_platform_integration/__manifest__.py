{
    "name": "CV Platform Integration",
    "version": "20.0.1.0.0",
    "summary": "Import CV Platform positions and aggregated results",
    "description": "Imports a position and its attribute/aggregate information from the deployed CVPlatform REST API.",
    "category": "Services",
    "author": "CVPlatform",
    "license": "LGPL-3",
    "depends": ["base"],
    "data": [
        "security/ir.access.csv",
        "views/cv_platform_position_views.xml",
        "wizard/import_position_views.xml",
    ],
    "installable": True,
    "application": True,
}
