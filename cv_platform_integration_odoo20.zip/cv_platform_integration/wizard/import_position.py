import json

import requests

from odoo import fields, models
from odoo.exceptions import UserError


class CVPlatformImportPosition(models.TransientModel):
    _name = "cvplatform.position.import"
    _description = "Import CV Platform Position"

    api_url = fields.Char(
        string="API URL",
        required=True,
        default="https://cvplatform-say18-bqbhg5febrfrdnev.westus3-01.azurewebsites.net",
    )
    api_token = fields.Char(string="API Token", required=True)

    def action_import(self):
        self.ensure_one()
        endpoint = self.api_url.strip().rstrip("/") + "/api/integration/position"

        try:
            response = requests.get(
                endpoint,
                headers={"X-Api-Token": self.api_token.strip()},
                timeout=20,
            )
        except requests.RequestException as exc:
            raise UserError(f"Could not connect to CVPlatform API: {exc}") from exc

        if response.status_code != 200:
            message = response.text[:1000] if response.text else response.reason
            raise UserError(
                f"CVPlatform API returned HTTP {response.status_code}: {message}"
            )

        try:
            payload = response.json()
        except ValueError as exc:
            raise UserError("CVPlatform API did not return valid JSON.") from exc

        title = payload.get("title")
        if not title:
            raise UserError("The API response does not contain a position title.")

        attributes = payload.get("attributes") or []
        aggregate_items = [
            {
                "title": attribute.get("title"),
                "type": attribute.get("type"),
                "aggregate": attribute.get("aggregate"),
            }
            for attribute in attributes
        ]

        self.env["cvplatform.position"].create({
            "name": title,
            "source_position_id": payload.get("positionId") or 0,
            "total_candidates": payload.get("totalCandidates") or 0,
            "attributes_json": json.dumps(attributes, ensure_ascii=False, indent=2),
            "aggregates_json": json.dumps(aggregate_items, ensure_ascii=False, indent=2),
        })

        return {
            "type": "ir.actions.act_window",
            "name": "Imported Positions",
            "res_model": "cvplatform.position",
            "view_mode": "list,form",
            "target": "current",
        }
