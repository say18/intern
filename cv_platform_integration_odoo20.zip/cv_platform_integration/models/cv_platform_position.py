from odoo import fields, models


class CVPlatformPosition(models.Model):
    _name = "cvplatform.position"
    _description = "CV Platform Imported Position"
    _order = "imported_at desc, id desc"

    name = fields.Char(required=True)
    source_position_id = fields.Integer(string="Source Position ID")
    total_candidates = fields.Integer(string="Total Candidates")
    attributes_json = fields.Text(string="Attributes JSON")
    aggregates_json = fields.Text(string="Aggregates JSON")
    imported_at = fields.Datetime(
        string="Imported At",
        default=fields.Datetime.now,
        required=True,
    )
